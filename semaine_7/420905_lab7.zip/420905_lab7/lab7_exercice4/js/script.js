// Variables globales
let gNbAmpoules = 0;

// Écouteurs d'événements (Rien à ajouter)
function init(){

    document.querySelector(".ampoule1").addEventListener("click", changerEtatAmpoule);
    document.querySelector(".ampoule2").addEventListener("click", changerEtatAmpoule);
    document.querySelector(".ampoule3").addEventListener("click", changerEtatAmpoule);
    document.querySelector(".ampoule4").addEventListener("click", changerEtatAmpoule);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter la fonction changerEtatAmpoule()
//
// - Dans le dossier images du projet, vérifiez les trois images. Pour les 
//   attributs src de nos ampoules, ça nous donne trois options : 
//   "images/off.png", "images/on.png" et "images/multi.png".
//
// - Si l'ampoule cliquée est éteinte (son alt vaut "Off") et possède la classe "multi", 
//   on l'allume avec l'ampoule multicolore et on change son alt pour "On".
// - Sinon, si elle est éteinte mais n'a pas la classe "multi", on l'allume 
//   avec l'ampoule jaune et on change son alt pour "On".
// - Sinon, on éteint l'ampoule et on change son alt pour "Off".
//
// - Notez qu'en tout temps, dans le bas de la page, on souhaite afficher
//   le nombre d'ampoules allumées avec le texte 
//   "X ampoules sont allumées". Remplacez le X par le nombre d'ampoules 
//   présentement allumées. Ça veut dire qu'il faudra garder le compte quand 
//   on allume ou éteint une ampoule.
// 
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function changerEtatAmpoule(event){



}