// Écouteur d'événements (Déjà créé)
function init(){

    document.querySelector(".bouton").addEventListener("click", inverser);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer et compléter la fonction inverser().
//
// - Défi : Utilisez UNE SEULE FOIS document.querySelector()
//
// - À l'aide d'une boucle, pour les 25 images, on veut inverser l'image 
//  (jake devient logan, logan devient jake) et basculer la présence de la 
//   classe "paul".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

