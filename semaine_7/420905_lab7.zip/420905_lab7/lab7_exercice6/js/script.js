// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Ajouer 16 écouteurs d'événement à l'aide d'une boucle
//
// - À l'aide d'une boucle avec une variable i qui vaudra de 1 à 16, ajoutez
//   un écouteur d'événements qui appelle la fonction stomp() quand on clique 
//   sur les éléments .case1, .case2, .case3, ... etc. jusqu'à .case16.
//
// - Si c'est bien complété, le jeu fonctionnera. Il n'y a rien
//   d'autre à coder.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    gameSetup(); // Ne pas toucher à cette ligne

    

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// NE PAS MODIFIER LE CODE À PARTIR D'ICI
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gScore = 0;
let gPlanificateur;

function startGame(){
    this.style.display = "none";
    setTimeout(endGame, 15000);
    gPlanificateur = setInterval(spawnMole, 750);
    gScore = 0;
    document.querySelector(".score").textContent = "Score : " + gScore;
}

function stomp(){
    if(this.getAttribute("src") == "images/voltorb.gif"){
        this.setAttribute("src", "images/busyHole.png");
        gScore -= 3;
        document.querySelector(".score").textContent = "Score : " + gScore;
        document.querySelector(".grille").style.borderColor = "crimson";
        setTimeout(resetBorder, 500);
    }
    else if(this.getAttribute("src") == "images/diglett.gif"){
        this.setAttribute("src", "images/busyHole.png");
        gScore += 1;
        document.querySelector(".score").textContent = "Score : " + gScore;
        document.querySelector(".grille").style.borderColor = "limegreen";
        setTimeout(resetBorder, 500);
    }
}

function resetBorder(){
    document.querySelector(".grille").style.borderColor = "black";
}

function endGame(){
    document.querySelector(".start").style.display = "block";
    clearInterval(gPlanificateur);
    for(let index = 1; index < 17; index += 1){
        document.querySelector(".case" + index).setAttribute("src", "images/hole.png");
    }
}

function spawnMole(){
    let notAvailable = true;
    let i;
    while(notAvailable){
        i = Math.floor(Math.random() * 16) + 1;
        if(document.querySelector(".case" + i).getAttribute("src") == "images/hole.png"){
            notAvailable = false;
        }    
    }
    if(Math.random() < 0.2){
        document.querySelector(".case" + i).setAttribute("src", "images/voltorb.gif");
    }
    else{
        document.querySelector(".case" + i).setAttribute("src", "images/diglett.gif");
    }
    setTimeout(cleanHole, 1000, i);
}

function cleanHole(index){
    document.querySelector(".case" + index).setAttribute("src", "images/hole.png");
}

function gameSetup(){
    document.querySelector(".start").addEventListener("click", startGame);
    for(let index = 1; index < 17; index += 1){
        document.querySelector(".case" + index).setAttribute("draggable", "false");
    }
}
