let gFruits = ["pomme", "banane", "orange"];

// Écouteurs d'événements déjà complétés
function init(){

    document.querySelector(".bouton1").addEventListener("click", double1);
    document.querySelector(".bouton2").addEventListener("click", double2);
    document.querySelector(".bouton3").addEventListener("click", boutonMin1);
    document.querySelector(".bouton4").addEventListener("click", boutonMin2);
    document.querySelector(".bouton5").addEventListener("click", banane);
    document.querySelector(".bouton6").addEventListener("click", aubergine);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Créer une fonction, compléter double1() et double2().
//
// Commencez par créer une fonction nommée doublerValeur() :
// - C'est une fonction qui reçoit un seul paramètre. (Un nombre)
// - La fonction retourne la valeur reçue, mais doublée.
//   (Donc par exemple, si la fonction reçoit 4, elle retourne 8)
//
// Pour la fonction double1() :
// - Cette fonction imprime dans la console le double de la valeur 5.
//   (Donc en gros, on affiche 10 dans la console, mais en appelant la 
//    doublerValeur() en lui passant la valeur 5)
//
// Pour la fonction double2() :
// - Cette fonction fait la même chose que double1(), mais elle affiche le
//   double de la valeur -3 plutôt que le double de 5.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► Créer la fonction doublerValuer() ici ◄


function double1(){



}

function double2(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer une fonction, compléter boutonMin1() et boutonMin2()
//
// Commencez par créer la fonction minimum() :
// - Elle reçoit deux paramètres. (Deux nombres)
// - Elle retourne le plus petit des deux nombres.
// - Pour y arriver, vous pouvez utiliser un if ... else.
//
// Compléter la fonction boutonMin1() :
// - Cette fonction crée une alerte avec la valeur la plus petite parmi 
//   2 et 3. (Donc on va faire une alerte avec la valeur 2, mais en se 
//   servant de la fonction minimum())
//
// Compléter la fonction boutonMin2() :
// - Cette fonction crée une alerte avec la valeur la plus petite parmi
//   -1 et 4. (Encore en se servant de la fonction minimum())
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► Créer la fonction maximum() ici ◄


function boutonMin1(){



}

function boutonMin2(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Créer une fonction, compléter banane() et onigiri()
//
// Commencez par créer la fonction chercherTableau(). 
// - Cette fonction reçoit 2 paramètres : un tableau et une chaîne de caractères.
// - Cette fonction retourne true si un des éléments du tableau est égal à
//   la chaîne de caractères reçue en paramètre. 
//   (Par exemples, si les paramètres sont ["a", "b", "c"] et "b", on
//    retourne true car "b" a bel et bien été trouvé dans le tableau !)
//   Pour réussir à faire cela, utilisez une boucle pour parcourir le tableau
//   reçu en paramètre ainsi qu'un if dans la boucle pour vérifier s'il y a
//   un élément égal à la chaîne de caractères reçue en paramètre.
//
// Compléter banane() :
// - Cette fonction remplace le texte de .texte par la valeur retournée par
//   la fonction chercherTableau() à laquelle on fournit les paramètres
//   gFruits et "banane".
//
// Compléter aubergine() :
// - Même chose que pour banane(), mais avec les paramètres gFruits et 
//   "aubergine".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► Créer la fonction chercherTableau() ici ◄


function banane(){



}

function aubergine(){



}