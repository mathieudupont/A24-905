// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder
//
// 💡 Indices 💡
// - N'hésitez pas à ajouter des variables globales, des écouteurs
//   d'événements et de nouvelles fonctions.
// - Initialement, le style nommé fontSize de l'élément .coeur vaut "15px". 
//   À chaque 10 millisecondes, on veut augmenter la taille en pixels de 1.
//   Le style fontSize passera donc à "16px", puis "17px", puis "18px", etc.
// - N'oubliez pas que le même bouton sert à activer et désactiver 
//   l'élargissement progressif du coeur.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀



function init(){



}

