
// Variables globales
let gDirection = "up";
let gVitesse = 0.5;
let gEtoilesRestantes = 15;
let gElementCollision;
let gPlanificateur;
let gCollisions = [];

// Écouteurs d'événements (Rien à ajouter)
function init(){
    document.addEventListener("keydown", changerDirection);
    document.querySelector(".jouer").addEventListener("click", jouer);
}


// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : fonction calculerScore
//
// - Créez une fonction nommée calculerScore qui prend comme paramètre 1 tableau
//   et qui retourne le score calculé selon les nombres de "⭐" et de "🌎" dans 
//   le tableau. Une "⭐" donne 3 points et une "🌎" en fait perdre 5.
//   (Autrement dit, pour chaque "⭐", on ajoute 3 au total et pour chaque
//   "🌎", on retire 5 au total. Finalement, on retourne ce total.)
//
//   (Gardez à l'esprit que le tableau reçu en paramètre ressemblera à 
//    ["🌎","⭐","⭐","🌎","⭐"] par exemple)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : fonction afficherScore
//
// - Dans cette fonction :
//      - Appelez la fonction calculerScore en lui passant le tableau gCollisions
//        et mettez le résultat retourné dans une variable nommée score.
//      - Affichez dans l'élément .score le texte suivant :
//          "SCORE : X" en remplaçant X par le score.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function afficherScore(){

    
    
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas toucher au code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function changerDirection(evenement){
    let touche = evenement.key;
    if(touche == "ArrowUp"){
        gDirection = "up";
    }
    else if(touche == "ArrowDown"){
        gDirection = "down";
    }
    else if(touche == "ArrowLeft"){
        gDirection = "left";
    }
    else if(touche == "ArrowRight"){
        gDirection = "right";
    }
}

function collision(){
    if(gElementCollision.classList.contains("planete")){
        retirerEtoile();
        gCollisions.push("🌎");
    }
    else{
        gEtoilesRestantes -= 1;
        retirerEtoile();
        gCollisions.push("⭐");
    }
}

function jouer(){
    gCollisions = [];
    document.querySelector(".score").textContent = "";
    gVitesse = 0.5;
    gDirection = "up";
    gEtoilesRestantes = 15;
    document.querySelector(".jouer").style.display = "none";
    let f = document.querySelector("#fusee");
    f.style.left = "380px";
    f.style.top = "460px";
    f.setAttribute("src", "images/fuseeU.png");
    gPlanificateur = setInterval(animerJeu, 10);
    lancerJeu();
}

function lancerJeu(){
    let elements = document.querySelectorAll(".obstacle");
    for(let e of elements){
        let x = Math.floor(Math.random() * 771);
        let y = Math.floor(Math.random() * 471);
        e.style.display = "block";
        e.style.top = y + "px";
        e.style.left = x + "px";
    }
}

function finPartie(){
    document.querySelector(".jouer").style.display = "block";
    clearInterval(gPlanificateur);
    afficherScore();
}

function retirerEtoile(){
    gElementCollision.style.display = "none";
    gElementCollision.style.left = "-50px";
}

function animerJeu(){
    document.querySelector(".reste").textContent = gEtoilesRestantes;
    if(gEtoilesRestantes == 0){
        alert("Bravo !");
        finPartie();
    }
    gVitesse += 0.0075;
    let f = document.querySelector("#fusee");
    let x = parseFloat(f.style.left);
    let y = parseFloat(f.style.top);
    switch(gDirection){
        case "up" : f.style.top = y - gVitesse + "px"; f.setAttribute("src", "images/fuseeU.png");
            break;
        case "down" : f.style.top = y + gVitesse + "px"; f.setAttribute("src", "images/fuseeD.png");
            break;
        case "left" : f.style.left = x - gVitesse + "px"; f.setAttribute("src", "images/fuseeL.png");
            break;
        default : f.style.left = x + gVitesse + "px"; f.setAttribute("src", "images/fuseeR.png");
    }
    x = parseFloat(f.style.left);
    y = parseFloat(f.style.top);
    if(x < 0 || x > 760 || y < 0 || y > 460){
        finPartie();
        document.querySelector("#fusee").setAttribute("src", 'images/explosion.png');
    }
    let elements = document.querySelectorAll(".obstacle");
    for(let e of elements){
        let oX = parseInt(e.style.left);
        let oY = parseInt(e.style.top);
        if(x < oX + 25 && x + 35 > oX && y < oY + 25 && y + 35 > oY){
            gElementCollision = e;
            collision();
        }
    }
}
