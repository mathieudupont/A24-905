// Variables globales du projet
let gCouleur = "bleu";

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Il faut tout coder ! Lisez les instructions dans la page HTML.
// - Notez qu'il y a deux images d'ampoules dans la page : une bleue et une 
//   rouge.
// - Vous aurez certainement besoin de la variable globale gCouleur.
// - Le bouton aura besoin d'un écouteur d'événements
// - Un if else vous aidera à faire alterner les deux ampoules.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀


function init(){

    // N'hésitez pas à ajouter du code ici


}

// N'hésitez pas à créer une nouvelle fonction ici
