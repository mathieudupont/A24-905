// Variables globales
let gBonheur = 50;

// Écouteurs d'événements déjà complétés
function init(){

    document.querySelector(".bouton1").addEventListener("click", gamer);
    document.querySelector(".bouton2").addEventListener("click", devoir);
    document.querySelector(".bouton3").addEventListener("click", tiktok);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Regarder ces trois fonctions
//
// - Ces fonctions sont déjà complétées. Selon le bouton sur lequel on a 
//   cliqué, une de ces fonctions sera appelée. Toutes les fonctions font la
//   même chose : elles appellent la fonction changerBonheur(), mais avec une
//   valeur différente. Gamer augmente le bonheur de +10, faire un devoir 
//   réduit le bonheur de -25 et tiktok augmente le bonheur de +1.
//
// - Vous pouvez maintenant aller faire le TODO 2.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function gamer(){
    changerBonheur(10);
}

function devoir(){
    changerBonheur(-25);
}

function tiktok(){
    changerBonheur(1);
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter la fonction changerBonheur
//
// - Notez que cette fonction possède un paramètre nommé valeur. Le paramètre
//   valeur représente la variation du bonheur. (+10, -25 ou +1, selon le
//   bouton qui a été utilisé)
//
// La fonction doit faire les choses suivantes :
//
// - Modifier la variable gBonheur. (augmenter / réduire à l'aide du paramètre
//   valeur)
// - Changer la couleur du texte de l'élément .bonheur
//      - "limegreen" si gBonheur est d'au moins 60
//      - Sinon, "gold" si gBonheur est entre 30 et 59 (inclus)
//      - Sinon, "crimson"
// - Assurez-vous que la valeur de gBonheur reste toujours entre 0 et 100 !
//   Par exemple, si le bonheur est déjà à 100 et qu'on l'augmente encore,
//   assurez-vous de ramener la valeur à 100 si nécessaire.
// - Finalement, on remplace le contenu textuel de l'élément .bonheur par la
//   phrase "Bonheur : X %", où X est remplacé par la valeur de gBonheur.
//   Par exemple, le texte pourrait devenir "Bonheur : 34 %" si gBonheur vaut
//   présentement 34.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function changerBonheur(valeur){



}