// -~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
// TODO 1 : Bogues simples 😇
// - Les boutons Texte bleu, Texte rouge et Texte vert fonctionnent mal.
// - Ils sont censés changer la couleur du texte dans la boîte en-dessous.
//
// - Les problèmes :
//      - Le bouton bleu ne fait rien.
//      - Le bouton rouge ne fait rien.
//      - Le bouton vert ne change pas la couleur de texte du bon élément.
// -~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-

function init(){
    document.querySelector(".bleu").addEventListener("clique", texteBleu);
    document.querySelector(".rouge").addEventListener("click", texteRouge);
    document.querySelector(".vert").addEventListener("click", texteVert);
}

function texteBleu(){
    document.querySelector(".texte").style.color = "blue";
}

function texteRouge(){
    document.querySelector("texte").color = "red";
}

function texteVert(){
    document.querySelector(".vert").style.color = "green";
}

