// Variables globales
let gEtat = "oeuf";

// Écouteurs d'événements déjà complétés
function init(){

    document.querySelector(".bouton1").addEventListener("click", weeWoo);
    document.querySelector(".bouton2").addEventListener("click", weeWoo);

    document.querySelector(".temps").addEventListener("click", avancerTemps);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter weeWoo()
// Cette fonction permettra aux deux boutons en haut de la page d'alterner 
// entre bleu et rouge.
// 
// - Si la couleur de fond de l'élément cliqué est "lightskyblue", on la
//   change pour "lightpink" et on change son texte pour "Woo 🚔".
// - Sinon, sa couleur de fond redevient "lighyskyblue" et son texte "Wee 🚔".
//
// En gros, cliquer à répétition sur un bouton va le faire basculer de
// bleu à rouge, à bleu, à rouge, etc.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function weeWoo(event){

    // SOLUTION
    if(event.currentTarget.style.backgroundColor == "lightskyblue"){
        event.currentTarget.style.backgroundColor = "lightpink";
        event.currentTarget.textContent = "Woo 🚔";
    }
    else{
        event.currentTarget.style.backgroundColor = "lightskyblue";
        event.currentTarget.textContent = "Wee 🚔";
    }
    // SOLUTION

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer la fonction changerMotDansPhrase()
// Cette fonction permettra de changer le texte des éléments .mot1, .mot2,
// .mot3, .mot4 ou .mot5
//
// Voici des exemples du fonctionnement de la fonction :
// - Si on appelle changerMotDansPhrase(2, "Salut"), alors le contenu textuel
//   de l'élément .mot2 deviendra "Salut".
// - Si on appelle changerMotDansPhrase(4, "Bye"), alors le contenu textuel
//   de l'élément .mot4 deviendra "Bye".
//
// En gros, le premier paramètre est un numéro qui permet de choisir quel
// élément parmi .mot1, .mot2, ... ou .mot5 sera modifié et le deuxième 
// paramètre est le texte qui ira dans l'élément. Rassurez-vous : il y a 
// moyen de réussir avec une seule ligne de code dans la fonction.
//
// Comme cette fonction n'est appelée nul part dans le code, vous allez
// devoir l'appeler dans la console pour tester qu'elle fonctionne bien. 
// Servez-vous des deux exemples plus haut pour vérifier qu'elle marche bien.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// SOLUTION
function changerMotDansPhrase(numero, mot){
    
    document.querySelector(`.mot${numero}`).textContent = mot;

}
// SOLUTION

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter avancerTemps()
// Dans la page, il y a un oeuf accompagné d'un bouton pour avancer le temps.
// Cliquer sur le bouton une fois transforme l'🥚 en 🐣. Cliquer une 
// deuxième fois transforme le 🐣 en 🐥. Cliquer une troisième fois transforme
// le 🐥 en 🐔.
// 
// Pour y arriver, vous devrez vous entre autres servir de la variable gEtat.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function avancerTemps(){

    // SOLUTION
    if(gEtat == "oeuf"){
        document.querySelector(".poulet").textContent = "🐣";
        gEtat = "eclosion";
    }
    else if(gEtat == "eclosion"){
        document.querySelector(".poulet").textContent = "🐥";
        gEtat = "poulet";
    }
    else{
        document.querySelector(".poulet").textContent = "🐔";
    }
    // SOLUTION

}