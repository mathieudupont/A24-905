// Aucune variable globale n'est nécessaire pour ce projet

// Exercice qui peut sembler difficile ! ⛔ N'hésitez surtout pas à 
// demander des pistes supplémentaires à l'enseignant APRÈS avoir lu
// les instructions une ou deux fois. 📜🔍

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Coder trois fonctions.
// - init() : Contient les écouteurs d'événements
// - on() : Allume l'ampoule
// - off() : Éteint l'ampoule
//
// 💡 Indices 💡
// - D'abord, remarquez qu'il y a 2 <img> dans le code HTML. Initialement, l'image
//   avec l'ampoule allumée est cachée grâce à style.display = "none". Si jamais on
//   souhaitait l'afficher, on pourrait simplement utiliser la ligne de code suivante :
//   document.querySelector(".lightOn").style.display = "block";
//
// - Quand on survole l'ampoule éteinte (.lightOff), un écouteur d'événements va 
//   appeler la fonction on(), qui cache l'ampoule éteinte et dévoile l'ampoule allumée.
//
// - Quand on arrête de survoler l'ampoule allumée (.lightOn), un écouteur d'événements va 
//   appeler la fonction off(), qui dévoile l'ampoule éteinte et cache l'ampoule allumée.
//
// - Vous aurez besoin de .style.display pour cacher / dévoiler les images d'ampoule.
//   La valeur "block" dévoile un élément. La valeur "none" cache un élément.
//      
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► Codez les trois fonctions ici ! ◄



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Testez l'ampoule !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
