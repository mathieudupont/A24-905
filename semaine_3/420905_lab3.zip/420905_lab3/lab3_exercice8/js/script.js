// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// La fonction init() est déjà complète.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    document.querySelector(".bouton1").addEventListener("click", actionBouton1);
    document.querySelector(".bouton2").addEventListener("click", actionBouton2);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Examiner les fonctions suivantes
//
// - Elles sont déjà complètes. Il ne faut pas les modifier. Toutefois, dans
//   dans le TODO 2, vous allez ajouter du code et vous allez devoir appeler
//   les fonctions ci-dessous en leur fournissant des paramètres.
//
// - Exemple : Dans une fonction, peut-être que je devrais utiliser la fonction
//   changerTailleElement(), qui demande 2 paramètres. Donc je pourrais 
//   écrire changerTailleElement(".baleine", 200) pour appeler la fonction
//   en passant les paramètres ".baleine" et 200.
//
// - Donc prenez le temps de bien analyser les fonctions ci-dessous pour
//   comprendre à quoi elles servent.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function changerTexteBouton1(texte){

    document.querySelector(".bouton1").textContent = texte;

}

function changerTailleElement(classe, tailleEnPixels){

    // style.fontSize change la taille du texte et des émojis
    document.querySelector(classe).style.fontSize = tailleEnPixels + "px";

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter les deux fonctions suivantes
//
// - Dans actionBouton1(), il y a une seule ligne de code à mettre. Il faut
//   appeler une fonction qui changera le texte de l'élément .bouton1. Le
//   nouveau texte doit être "aaaaaaaa 😩". Vous devez absolument appeler une 
//   fonction pour le faire. (Plutôt que d'écrire document.querySelector... 
//   vous-mêmes)
//
// - Dans actionBouton2(), il y a quatre ligne de code à mettre. Il faut 
//   appeler quatre fois la même fonction. Le but est de modifier la taille
//   du texte pour les éléments suivants :
//      • Taille de 20 pixels pour .poisson
//      • Taille de 40 pixels pour .dauphin
//      • Taille de 80 pixels pour .requin
//      • Taille de 160 pixels pour .baleine
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function actionBouton1(){

    // Ajouter du code ici

}

function actionBouton2(){

    // Ajouter du code ici

}