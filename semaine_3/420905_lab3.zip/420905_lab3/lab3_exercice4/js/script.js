// Ce projet n'a aucune variable globale

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Regarder la fonction init()
// - Il n'y a rien à ajouter dans la fonction init(). Un écouteur d'événements
//   de type "click" est déjà créé pour tous les boutons.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    document.querySelector(".bouton1").addEventListener("click", couleurTexte);
    document.querySelector(".bouton2").addEventListener("click", couleurFond);
    document.querySelector(".bouton3").addEventListener("click", couleurBordure);
    document.querySelector(".bouton4").addEventListener("click", largeurBordure);
    document.querySelector(".bouton5").addEventListener("click", tailleBouton);
    document.querySelector(".bouton6").addEventListener("click", opaciteBouton);
    document.querySelector(".bouton7").addEventListener("click", visibiliteBouton);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter toutes les fonctions ci-dessous à l'aide du commentaire 
//          fourni
// - Toutes les fonctions modifient le style d'un bouton.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// couleurTexte() : Le texte du .bouton1 deviendra de couleur "red".
function couleurTexte(){
    
    // Ajouter du code ici

}

// couleurFond() : Le fond du .bouton2 deviendra de couleur "gold".
function couleurFond(){
    
    // Ajouter du code ici
    
}

// couleurBordure() : La bordure du .bouton3 deviendra de couleur "blue".
function couleurBordure(){
    
    // Ajouter du code ici
    
}

// largeurBordure() : La bordure du .bouton4 deviendra de taille "10px".
function largeurBordure(){
    
    // Ajouter du code ici
    
}

// tailleBouton() : La largeur du .bouton5 deviendra de taille "300px".
//                  La hauteur du .bouton5 deviendra de taille "100px".
function tailleBouton(){
    
    // Ajouter du code ici
    
}

// opaciteBouton() : L'opacité du .bouton6 deviendra 0.2.
function opaciteBouton(){
    
    // Ajouter du code ici
    
}

// visibiliteBouton() : Le .bouton7 disparaîtra.
function visibiliteBouton(){
    
    // Ajouter du code ici
    
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Testez tout si ce n'est pas fait !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
