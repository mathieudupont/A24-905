// Variables globales du projet
let gCompteur = 0;

// N'OUBLIEZ PAS DE TESTER LES FONCTIONNALITÉS QUE VOUS CODEZ ! 😨

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter la fonction init()
//
// - Créez simplement la fonction init() pour commencer.
// - En réalisant le TODO 2, vous serez amenés à ajouter deux écouteurs 
//   d'événements dans init().
//
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► Déclarez la fonction init() ici ◄



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Créer deux fonctions pour augmenter / réduire la valeur du compteur
//
// - Première fonction, que vous nommerez reduireCompteur() :    
//      - Est appelée lorsqu'on clique sur le bouton 🔽 (Écouteur d'événements 
//        à ajouter dans init())
//      - Réduit la valeur de la variale globale gCompteur de 1.
//      - Affiche la nouvelle valeur de gCompteur dans la page. (Changer le 
//        contenu textuel de l'élément avec la classe .compteur)
//
// - Deuxième fonction, que vous nommerez augmenterCompteur() :    
//      - Est appelée lorsqu'on clique sur le bouton 🔼
//      - Augmente la valeur de gCompteur de 1.
//      - Affiche la nouvelle valeur de gCompteur dans la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► Déclarez vos deux fonctions ici ◄



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Vérifiez que vos deux boutons fonctionnent bien !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
