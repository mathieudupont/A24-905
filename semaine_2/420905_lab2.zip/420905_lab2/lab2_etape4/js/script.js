// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•
// Étape 4 - Créer vos propres fonctions !
// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•

// ⭐ N'OUBLIEZ PAS qu'une fonction possède la structure suivante :
// • Le mot-clé function
// • Un nom pour identifier la fonction
// • Des parenthèses vides après le nom
// • Une accolade ouvrante { pour indiquer où la fonction commence
// • Une accolade fermante } pour indiquer où la fonction termine

// 🤓 Après avoir codé une fonction, allez la tester dans la console de la page Web !

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Fonction nommée quatreEtCinq() qui remplace le texte des éléments avec les classes 
// .quatre et .cinq par "Zombies 🧟‍♂️" et "Vampires 🧛‍♂️", respectivement.
//
//
// Indices :
// - À l'aide de querySelector, de textContent et de l'opérateur =, vous pourrez changer le
//   contenu textuel de ces deux éléments grâce à deux lignes de codes similaires.
// - N'hésitez pas à copier-coller les chaînes de caractères ci-dessus si vous avez du mal 
//   à reproduire les émojis.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► ÉCRIRE LA FONCTION quatreEtCinq() ICI ! ◄



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Fonction nommée byeLicornes() qui remplace le contenu textuel de l'élément avec la
//          classe .trois par "". (C'est une chaîne de caractères vide !) et qui génère un 
//          pop-up (une alerte) avec le texte "Bye 😭".
// 
// Indice :
// - Encore une fois, il faudra utiliser textContent = ... pour changer du texte.
// - Vous aurez besoin de l'instruction alert(...) pour générer le pop-up.
// - Il y a deux lignes de code à mettre dans la fonction.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► ÉCRIRE LA FONCTION byeLicornes() ICI ! ◄



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Fonction nommée test() qui affiche le texte "Test réussi !" dans la console.
// 
// Indice :
// - Il suffira d'utiliser console.log(...).
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► ÉCRIRE LA FONCTION test() ICI ! ◄



// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Fonction nommée texteDeux() qui concatène " et génies 🧞" à l'élément avec la classe 
// .deux.
//
// Indice : L'opérateur += sera nécessaire, puisqu'on veut AJOUTER du texte plutôt que 
//          remplacer le texte déjà présent.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ► ÉCRIRE LA FONCTION texteDeux() ICI ! ◄

