// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// ⭐⭐ Cet exercice est plus dur. C'est pour vous préparer au TP2 ! ⭐⭐
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let gVitesseRotation = 0.5;
let gScore = 0;

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Ajoutez des écouteurs d'événements plus tard, au besoin
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    // Gardez ces écouteurs d'événements !
    document.querySelector(".bouton1").addEventListener("click", lancerJeu);
    document.querySelector(".bouton2").addEventListener("click", finJeu);

    // Ajoutez d'autres écouteurs d'événements ici



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter clicItem()
//
// ⭐ Gestion des points ⭐
//
// - Il faudra que tous les items dans la page (qui partagent la classe .item)
//   puissent être cliquables. (Allez ajouter des écouteurs d'évenements avec
//   une boucle dans init() !) 
//
// (Attention ! Pour modifier le score, vous êtes obligés d'utiliser la
// fonction modifierEtAfficherScore, qui est présente plus bas dans le code)
//
// - Cliquer sur un 📞 fait perdre 2 points et cliquer sur un 💬 fait gagner 
//   1 point. (pour vérifier ce qui vient d'être cliqué, utilisez 
//   e.currentTarget.textContent == "📞" ou e.currentTarget.textContent == "💬" !)
// - À chaque fois qu'on clique sur un 💬, augmentez également la vitesse de
//   rotation du jeu de 0.25. Modifier la bonne variable globale sera 
//   suffisant, le jeu va s'adapter automatiquement.
// - Faites disparaître l'élément cliqué !
//
// - Avant de conclure la fonction, appelez verifierSiPartieFinie().
//
// (Commencez par tester les fonctionnalités ci-dessus avant de poursuivre !)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function clicItem(event){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter verifierSiPartieFinie()
//
// ⭐ Fin de la partie ⭐
//
// - À chaque fois qu'on clique sur un item, cette fonction aura été appelée 
//   et on doit vérifier s'il reste des "💬" visibles dans le jeu. S'il reste 
//   zéro "💬" visible dans jeu, c'est qu'il faut mettre fin au jeu en 
//   appelant finJeu() ! Pour y arriver, vous allez devoir créer une boucle 
//   qui parcourt tous les éléments HTML qui ont la classe ".item". Pour 
//   chacun d'eux, vous pourrez utiliser cette condition à compléter :
//   (...textContent == "💬" && ...style.display == "block")
//   Cette condition sert à vérifier qu'un item est un 💬 ET qu'il est visible.
// - Normalement, vous aurez stocké le nombre de "💬" restant dans une variable.
//   Si elle est égale à 0, appelez la fonction finJeu().
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function verifierSiPartieFinie(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Fonctions déjà complétées à appeler plus haut !
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Fonction à appeler pour arrêter le jeu (cache les items restants)
function finJeu(){

    let items = document.querySelectorAll(".item");
    for(let i of items){
        i.style.display = "none";
    }

}

// Fonction à appeler pour modifier le score affiché. Il faut juste lui fournir,
// en paramètre, la valeur de variation. (Donc 1 ou -2)
function modifierEtAfficherScore(valeur){
    gScore += valeur;
    document.querySelector(".score").textContent = gScore;
}


// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Pas besoin de regarder le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

let zGameLoop;
let zAngle;
let zDistance;
let zDistanceCroissante;

function lancerJeu(){

    clearInterval(zGameLoop);
    zGameLoop = setInterval(gameLoop, 25);
    zDistance = 3;
    zDistanceCroissante = true;
    gVitesseRotation = 0.5;
    zAngle = 0;
    gScore = 0;
    document.querySelector(".score").textContent = gScore;
    let items = document.querySelectorAll(".item");
    for(let i of items){
        i.style.display = "block";
    }

}

function gameLoop(){

    zAngle = (zAngle + Math.PI * gVitesseRotation / 100) % (2 * Math.PI); 
    let delta = Math.PI / 6;
    let items = document.querySelectorAll(".item");

    if(zDistanceCroissante == true){
        zDistance += 0.2;
    }
    else{
        zDistance -= 0.2;
    }

    if(zDistance >= 10){
        zDistanceCroissante = false;
    }
    else if(zDistance <= 3){
        zDistanceCroissante = true;
    }

    for(let i = 0; i < items.length; i += 1){
        if(i % 2 == 0){
            items[i].style.left = 365 + 8 * (i + zDistance) * Math.cos(zAngle + delta * i) + "px";
            items[i].style.top = 320 + 8 * (i + zDistance) * Math.sin(zAngle + delta * i) + "px";
        }
        else{
            items[i].style.left = 365 + 8 * (i + 13 - zDistance) * Math.sin(zAngle + delta * i) + "px";
            items[i].style.top = 320 + 8 * (i + 13 - zDistance) * Math.cos(zAngle + delta * i) + "px";
        }
    }

}