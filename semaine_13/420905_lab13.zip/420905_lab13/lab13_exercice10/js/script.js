// Variables globales
let gAnimaux = ["🐄", "🐖"];
let gArgent = 5000;

// Écouteurs d'événements
function init(){

    document.querySelector(".bouton1").addEventListener("click", acheterCochon);
    document.querySelector(".bouton2").addEventListener("click", acheterVache);
    document.querySelector(".bouton3").addEventListener("click", vendreCochon);
    document.querySelector(".bouton4").addEventListener("click", vendreVache);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter acheterCochon(), acheterVache(), vendreCochon() et
//          vendreVache(). Créer d'autres fonctions, au besoin.
//
// ⛔ Interdit d'ajouter des variables globales ou des écouteurs d'événements ⛔
//
// - Servez-vous du tableau gAnimaux pour noter les animaux possédés.
// - N'oubliez pas de toujours mettre à jour l'affichage de l'argent et des
//   animaux dans la grange après chaque achat / vente.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function acheterCochon(){



}

function acheterVache(){



}

function vendreCochon(){



}

function vendreVache(){



}

