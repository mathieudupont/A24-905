
// Écouteurs d'événements (Oui ils ne sont pas très jolis 👄)
function init(){

    document.addEventListener("keydown", toucheClavier);
    document.querySelector(".bouton1").addEventListener("click", function(){
        nbDeSymboles(document.querySelector(".texte").textContent)
    });
    document.querySelector(".bouton2").addEventListener("click", function(){
        retirerDernierSymbole(document.querySelector(".texte").textContent)
    });
    document.querySelector(".bouton3").addEventListener("click", function(){
        oeufDevientPoule(document.querySelector(".texte").textContent)
    });
    document.querySelector(".bouton4").addEventListener("click", function(){
        m_deviennent_b(document.querySelector(".texte").textContent)
    });
    document.querySelector(".bouton5").addEventListener("click", function(){
        minuscules(document.querySelector(".texte").textContent)
    });
    document.querySelector(".bouton6").addEventListener("click", function(){
        majuscules(document.querySelector(".texte").textContent)
    });
    document.querySelector(".bouton7").addEventListener("click", function(){
        dernierSymbole(document.querySelector(".texte").textContent)
    });

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter nbDeSymboles()
//
// 💡 Notez que pour cette fonction (et toutes les suivantes), le paramètre
// texte contient le contenu textuel de l'élément .texte dans la page. 💡
// 
// - Lancer une alerte avec le message "Il y a X caractères." où X sera 
//   remplacé avec la taille (longueur) du texte.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function nbDeSymboles(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter retirerDernierSymbole()
//
// - Retirer le dernier caractère affiché dans le texte à l'aide de la
//   fonction substring().
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function retirerDernierSymbole(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter oeufDevientPoule()
//
// - Remplacez la première occurence de "oeuf" dans le texte par "poule" dans
//   le texte affiché. (Seulement la première !)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function oeufDevientPoule(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Compléter m_deviennent_b()
// 
// - Remplacez TOUTES les occurences de "m" par "b" dans le texte affiché.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function m_deviennent_b(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 5 : Compléter minuscules()
//
// - Rendez le texte affiché en tout en minuscules.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function minuscules(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 6 : Compléter majuscules()
//
// - Rendez le texte affiché en tout en majuscules.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function majuscules(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 7 : Compléter dernierSymbole()
//
// - À l'aide de la fonction charAt(), affichez le dernier caractère du texte
//   dans une alerte.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function dernierSymbole(texte){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas modifier le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function toucheClavier(e){
    if(e.key == " " || e.key == "'"){
        e.preventDefault();
    }
    if(e.key.length == 1){
        document.querySelector(".texte").textContent += e.key;
    }
    if(e.key == "Backspace"){
        document.querySelector(".texte").textContent = 
        document.querySelector(".texte").textContent.substring(0, 
            document.querySelector(".texte").textContent.length - 1)
    } 
    if(e.key == "Enter"){
        document.querySelector(".texte").textContent = "";
    }
}