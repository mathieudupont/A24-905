// Écouteurs d'événements
function init(){

    document.querySelector(".up").addEventListener("click", augmenterNombre);
    document.querySelector(".down").addEventListener("click", reduireNombre); 

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 0 : Si vous ne savez pas comment les nombres romains de 1 à 100
// fonctionnent ... lisez ceci ! Sinon, passez au TODO 1 !
//
// - "I" vaut 1, "V" vaut 5, "X" vaut 10, "L" vaut 50 et "C" vaut 100.
// - Un nombre romain ressemble à "LXVII" (67) Donc en additionnant les 
//   symboles on peut connaître la valeur. 
// - Notez que les symboles sont ordonnés de la plus grande valeur (L) à 
//   la plus petite valeur. (I)
// - Pour éviter de répéter un symbole 4 fois, (Ex : écrire IIII pour 4),
//   on fait une « soustraction » en inversant deux symboles. Par exemple, 
//   IV vaut 4 (5 moins 1), IX vaut 9 (10 - 1), XL vaut 40 (50 - 10), etc.
// - Si c'est vague ou pas clair, pas de panique : ce n'est pas essentiel de
//   comprendre les nombres romains pour cet exercice, puisque vous n'allez
//   pas les convertir vous-mêmes.
// - Prenez au moins connaissance des nombres de 1 à 10 :
// - I, II, III, IV, V, VI, VII, VIII, IX, X
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter les fonctions augmenterNombre() et reduireNombre()
//
// Comme les compteurs habituels, deux boutons permettent d'augmenter de 1
// et de réduire de 1 le compteur. Quand on utilise les boutons, on doit
// modifier le nombre ordinaire affiché et le nombre romain affiché.
//
// - Le défi pour cet exercice sera d'appeler plusieurs fonctions qui feront
//   la tâche à accomplir à votre place à cause de toutes les contraintes
//   qui vous limitent !
//
// ⛔ Contraintes ⛔
// - Pas le droit d'utiliser : if, else, else if, while, for, switch ou
//   document.querySelector().
// - Pas le droit d'ajouter des variables globales, de créer des écouteurs
//   d'événements supplémentaires ou de créer de nouvelles foncions.
// - Le nombre affiché dans la page doit toujours rester entre 1 et 100.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function augmenterNombre(){



}

function reduireNombre(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// ⭐ Ci-dessous, il y a de nombreuses fonctions que vous aurez besoin 
// d'appeler. Le défi prinicipal de cet exercice sera d'analyser les fonctions 
// qui sont à votre disposition et de bien les utiliser ⭐
//
// - LISEZ BIEN les descriptions des fonctions. 🔍
// - Certaines fonctions ne vous serviront pas du tout ! ❌
// - Pas le droit de modifier le code ci-dessous ! ⛔
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Cette fonction retourne le nombre qui est à gauche dans la page Web
function obtenirNombre(){

    return parseInt(document.querySelector(".nombre").textContent);

}

// Cette fonction prend un nombre ordinaire en paramètre et retourne sa
// version romaine. (Ex : convertirEnNombreRomain(18) retourne "XVIII")
function convertirEnNombreRomain(n){

    if(n == 100){
        return "C";
    }
    else{
        return symbolesSelonPosition((n % 100 - n % 10) / 10, "X", "L", "C") 
            + symbolesSelonPosition(n % 10, "I", "V", "X");
    }
}

// Cette fonction remplace le contenu textuel d'un élément dans la page.
// On doit donner en paramètre la classe de l'élément et le texte à mettre.
function mettreTexteDansElement(classe, texte){
    document.querySelector(classe).textContent = texte;
}

// Cette fonction prend une valeur et trois symboles en paramètres. Elle
// retourne une série de symbole qui dépend de la valeur et des symboles
// choisis.
function symbolesSelonPosition(valeur, un, cinq, dix){
    if(valeur == 9){
        return un + dix;
    }
    else if(valeur >= 5){
        return cinq + chaineSymboles(un, valeur - 5);
    }
    else if(valeur == 4){
        return un + cinq;
    }
    else{
        return chaineSymboles(un, valeur);
    }
}

// Cette fonction retourne une chaîne avec le même symbole répété un
// nombre de fois demandé. Par exemple, chaineSymboles("X", 3) retourne
// "XXX".
function chaineSymboles(symbole, nbFois){
    let chaine = "";
    while(nbFois > 0){
        chaine += symbole;
        nbFois -= 1;
    }
    return chaine;
}