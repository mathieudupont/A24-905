// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Rendre la page fonctionnelle
//
// - Créez autant de fonctions que nécessaire. Si vous voulez ajouter des
//   écouteurs d'événements, ce sera dans init(), comme d'habitude.
// - Remarquez que les ampoules ont tous la même classe commune.
//   (Pas le droit de modifier le HTML et le CSS, bien entendu)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Écouteurs d'événements
function init(){



}

