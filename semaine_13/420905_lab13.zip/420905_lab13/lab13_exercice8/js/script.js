

function init(){

    // Dès l'ouverture de la page, la fonction prochaineImage sera appelée
    // toutesles 500 millisecondes.
    setInterval(prochaineImage, 500);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter prochaineImage()
//
// - Vous pouvez créer des variables globales si vous en avez besoin.
//   (C'est possible sans)
// - Vous pouvez créer d'autres fonctions si vous en avez besoin.
//   (C'est possible sans)
// - Vous n'avez pas à créer des écouteurs d'événements.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function prochaineImage(){



}

