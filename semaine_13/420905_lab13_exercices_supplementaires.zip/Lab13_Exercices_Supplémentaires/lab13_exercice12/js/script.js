// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 :
//
// Dans cet exercice nous allons implémenter un jeu qui va compter le nombre de
// lettres que l'on peut entrer au clavier en trente secondes.
//
// Il y a trois éléments HTML que l'on doit utiliser:
//
// ** l'élément de classe "lettre" contiendra la lettre actuelle à entrer
// ** l'élément de classe "temps" contiendra le texte "Temps restant: X s"
//        avec le temps en secondes
// ** l'élément de classe "score" contiendra le texte "Score: X" avec X le
//        score actuel
//
// Lorsque le bouton Commencer de classe "bouton" est cliqué: on remet le
// temps à 30 s, on remet le score à 0, on choisit une lettre au hasard et
// on affiche tout cela dans la page html. Un planificateur est enclenché
// pour diminuer le temps.
//
// Dans la fonction utilisée par le planificateur, il faudra implémenter la 
// logique si le temps est écoulé. Une alerte avec le score sera envoyée à
// l'utilisateur dans ce cas et le planificateur sera arrêté.
//
// Lorsqu'une touche du clavier est pressée, on la comparera avec la touche
// à entrer, on augmentera le score de 1 si c'est le cas, sinon on le
// diminuera de 1. 
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// CODE ICI

function init()
{
// CODE ICI
}

// CODE ICI