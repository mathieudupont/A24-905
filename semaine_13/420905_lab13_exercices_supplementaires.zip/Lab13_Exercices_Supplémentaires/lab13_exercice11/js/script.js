// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Variables globales
//
// Une fois que l'exercice sera fini, libre à vous de changer, d'enlever ou
// de rajouter des lieux (avec leurs coordonnées en latitude et longitude).
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

gNomLieu =   ["Longueuil", "Everest", "Sahara",  "Amazonie", "Pôle Sud"];
gLatitude =  [ 45.53640,    27.98833,  21.00000,  -6.00000,  -90.00000 ];
gLongitude = [-73.49478,    86.92528,  -3.00000, -60.00000,    0.00000 ];

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter init().
//
// On veut rajouter les données météorologiques actuelles de chaque lieu
// dans la page HTML.
//
// Regardez d'abord la fonction obtenirMeteo(), c'est elle que vous allez 
// utiliser pour obtenir les données. 
//
// Pour chaque lieu (attention, votre code doit marcher si la longueur des
// tableaux gNomLieu, gLatitude, gLongitude est modifiée, utilisez donc une
// boucle for):
// ** récupérez les données
// ** ajoutez un élément `div` de classe "lieu" dans l'élément de classe "meteo"
// ** dans ce nouvel élément:
//      -- nom du lieu: ajoutez un élément `p`, donnez-lui la classe "nomlieu"
//               et la donnée de gNomLieu dans son contenu textuel
//      -- jour: ajoutez un élément `p`, donnez-lui la classe "icon", 
//               si jour est true on veut y afficher: "☀️", sinon "🌙"
//      -- température: ajoutez un élément `p`, rajoutez-lui le contenu textuel `X °C`
//               avec X la valeur de temperature
//      -- pression atmosphérique: ajoutez un élément `p`, rajoutez-lui le contenu 
//               textuel `X kPa` avec X la valeur de pression_atm
//      -- état: ajoutez un élément `p`, donnez-lui la classe "icon"
//              S'il pleut
//                          affichez: "🌧️"
//              Sinon s'il neige
//                          affichez: "🌨️"
//              Sinon si la couverture nuageuse est supérieure strictement à 50%
//                          afficher: "☁️"
//
// ⛔ Vous devez seulement rajouter du code dans la fonction init() ⛔
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function init(){
    
    // CODE ICI
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas toucher au code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function obtenirMeteo(latitude, longitude, lieu)
{
    /** 
     * Permet d'obtenir les données météorologiques aux coordonnées spécifiés
     * via l'API de https://api.open-meteo.com.
     * 
     * @param latitude  - la latitude en degré entre -90 et 90
     * @param longitude - la longitude en degré entre -180 (O) et 180 (E)
     * @param lieu      - le nom du lieu, seulement utilisé pour l'alerte
     * 
     * @returns - retourne un tableau de données avec le format suivant:
     *            [jour, temperature, pression_atm, nuage, pluie, neige]
     *            jour: booléen (true = journée, false = nuit)
     *            temperature: température en degré Celsius
     *            pression_atm: pression atmosphérique en kPa
     *            nuage: couverture nuageuse en pourcentage
     *            pluie: booléen (true = pluie)
     *            neige: booléen (true = neige)
     * 
     * Si la requête http échoue, la fonction retourne des données aléatoires
    */

    // On crée des données aléatoires au cas où la requête http échoue
    let jour = Math.random() > 0.5;
    let temperature = Math.round(Math.random() * 90 - 40);
    let pression_atm = Math.round(Math.random() * 100 + 950);
    let nuage = Math.round(Math.random() > 0.5 ? 0 : Math.random()*100);
    let pluie = Math.random() > 0.5;
    let neige = Math.random() > 0.5;
    try{
        // On essaye d'effectuer la requête
        let serviceUrl = `https://api.open-meteo.com/v1/forecast?`;
        let parametreUrl = `latitude=${latitude}&longitude=${longitude}`;
        let demandeUrl = `&current=temperature_2m,is_day,rain,snowfall,cloud_cover,pressure_msl`;
        apiUrl = serviceUrl + parametreUrl + demandeUrl;
        let xmlHttp = new XMLHttpRequest();
        xmlHttp.open("GET", apiUrl, false); // la requête est synchrone pour simplifier le code 
        xmlHttp.send(null);
        donnees = JSON.parse(xmlHttp.responseText)[`current`];
        jour = donnees[`is_day`] == 1 ? true : false;
        temperature = donnees[`temperature_2m`];
        pression_atm = donnees[`pressure_msl`];
        nuage = donnees[`cloud_cover`];
        pluie = donnees[`rain`] != 0 ? true : false;
        neige = donnees[`snowfall`] != 0 ? true : false;
    }
    catch(error){
        // Si la requête échoue on envoie une alerte
        alert(`Données aléatoires pour ${lieu}`);
    }
    return [jour, temperature, pression_atm, nuage, pluie, neige];
}