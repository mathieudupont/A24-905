// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
//(⭐ Défi)
// Changez votre code pour faire la même chose avec, au maximum:
// - une variable globale (pensez tableau)
// - deux lignes de code contenant un `addEventListener` (pensez boucle)
// - une seule fonction (le nom de la classe de l'élément HTML avec lequel
//   on interagit contient beaucoup d'information, quand il n'y a qu'une 
//   classe on peut obtenir son nom en faisant elementHtml.classList[0])
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// CODE ICI