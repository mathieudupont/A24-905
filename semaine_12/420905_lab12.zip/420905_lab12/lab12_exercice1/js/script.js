
// Écouteurs d'événements déjà créés
function init(){

    document.querySelector(".bouton1").addEventListener("click", boucle1);
    document.querySelector(".bouton2").addEventListener("click", boucle2);
    document.querySelector(".bouton3").addEventListener("click", boucle3);
    document.querySelector(".bouton4").addEventListener("click", boucle4);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter boucle1()
//
// - Videz le contenu textuel de .texte.
// - À l'aide d'une boucle for, affichez les nombres de 0 à 10 dans le contenu
//   textuel de .texte. Séparez-les avec des espaces !
//   (On veut "0 1 2 3 4 ...", pas "01234 ...")
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function boucle1(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter boucle2()
//
// - À l'aide d'une boucle for, ajoutez la classe "multicolore" aux éléments
//   .minerai1, .minerai2, .minerai3, ... jusqu'à .minerai9.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function boucle2(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter boucle3()
//
// - À l'aide d'une boucle for, calculez la somme des nombres de 5 à 25 
//   (inclus) et affichez ce nombre dans une alerte ensuite.
//
// (Pour référence, ça donne 315)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function boucle3(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Compléter boucle4()
//
// - À l'aide d'une boucle for, calculez la somme des nombres impairs de 11 
//   à 33 (inclus) et affichez ce nombre dans une alerte ensuite.
//   (Indice : Au lieu de faire i += 1, utilisez i += 2 !)
//
// (Pour référence, ça donne 264)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function boucle4(){



}