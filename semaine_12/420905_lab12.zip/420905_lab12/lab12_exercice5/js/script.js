let gDureeTheorie = 30;
let gDureeExercices = 90;
let gCoursInteressant = true;

// Écouteurs d'événements
function init(){

    document.querySelector(".bouton1").addEventListener("click", alternerCoursInteressant);
    document.querySelector(".bouton2").addEventListener("click", function(){changerDureeTheorie(-10)});
    document.querySelector(".bouton3").addEventListener("click", function(){changerDureeTheorie(10)});
    document.querySelector(".bouton4").addEventListener("click", function(){changerDureeExercices(-10)});
    document.querySelector(".bouton5").addEventListener("click", function(){changerDureeExercices(10)});

    document.querySelector(".boutonA").addEventListener("click", messageExercices);
    document.querySelector(".boutonB").addEventListener("click", messageTheorie);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter messageExercices()
//
// - À l'aide d'une condition ternaire, affichez le message "Le labo est bien 😌"
//   si la durée des exercices est inférieure à 90 minutes. Affichez le
//   message "Y'a trop d'exercices 😩" sinon.
//
// (Votre condition ternaire devra remplacer "texte temporaire", ce qui 
// donnera juste une longue ligne de code seule.)
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageExercices(){

    document.querySelector(".texte").textContent = "texte temporaire";

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter messageTheorie()
//
// - À l'aide d'une condition ternaire, il faut mettre le message
//   "La théorie était endurable 🤔" si la durée de la théorie est inférieure
//   à 30 minutes OU si le cours était intéressant. Sinon, le message sera
//   "😴😴😴".
//
// (Votre condition ternaire devra remplacer "texte temporaire")
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageTheorie(){

    document.querySelector(".texte").textContent = "texte temporaire";

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Ne pas modifier le code à partir d'ici
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function alternerCoursInteressant(){
    gCoursInteressant = !gCoursInteressant;
    document.querySelector(".coursInteressant").textContent = gCoursInteressant;
}

function changerDureeTheorie(variation){
    gDureeTheorie = Math.max(0, gDureeTheorie + variation);
    document.querySelector(".dureeTheorie").textContent = gDureeTheorie;
}

function changerDureeExercices(variation){
    gDureeExercices = Math.max(0, gDureeExercices + variation);
    document.querySelector(".dureeExercices").textContent = gDureeExercices;
}